#include <stdio.h>
#include <stdlib.h>
void jungle_animal(animal[],my_speed)
{
	if(animal=="zebra")
	{
		printf("Try to ride a zebra!");
	}
	else if(animal=="cheetah")
	{
		if(my_speed>115)
		{
			printf("Run!\n");
		}
		else
			{	
				printf("Stay calm and wait!\n");
			}		
	}
	else
	{
		printf("Introduce yourself!\n");
	}
	
}




int main()
{
	char animal[20];
	int my_speed;
	printf("Enter the animal you see\n");
	gets(animal);
	printf("Enter your speed\n");
	scanf("%d",my_speed);
	jungle_animal(animal,my_speed);
	return 0;
}

//test case
*/#include <stdio.h>
#include <stdlib.h>
void jungle_animal(animal[],my_speed)
{
	if(animal=="zebra")
	{
		printf("Try to ride a zebra!");
	}
	else if(animal=="cheetah")
	{
		if(my_speed>115)
		{
			printf("Run!\n");
		}
		else
			{	
				printf("Stay calm and wait!\n");
			}		
	}
	else
	{
		printf("Introduce yourself!\n");
	}
	
}




int main()
{
	char animal[20];
	int my_speed;
	printf("Enter the animal you see\n");
	gets(animal);
	printf("Enter your speed\n");
	scanf("%d",my_speed);
	jungle_animal(animal,my_speed);
	return 0;
}

//test case
#jungle_animal('cheetah', 30)
#>>> "Stay calm and wait!"

#jungle_animal('gorilla', 21)
#>>> "Introduce yourself!"

Language Used : C