#include <stdio.h>
#include <stdlib.h>
void is_leap_baby(day,month,year)
{
	int status;
	if(year%4 && year%100)
	{
		status=1;
		output(name,status);
	}
	else
	{
		status=0;
		output(name,status);
	}
	return status;
}

void output(name,status)
{
	if(status=1)
	{
		printf("%s is one of an extremely rare species. He is a leap year baby!\n")
	}
	else
	{
		printf("There's nothing special about %s's birthday. He is not a leap year baby!\n");
	}
}

void main()
{
	int date,month,year;
	char name[10];
	printf("Enter the name of child\n");
	scanf("%s",&name);
	printf("Enter the birth date of child\n");
	scanf("%d/%d/%d",&date,&month,&year);
	output(is_leap_baby(date,month,year),name);
}


//test case
def test():
    test_cases = [((2012,1,1,2012,2,28), 58), 
                  ((2012,1,1,2012,3,1), 60),
                  ((2011,6,30,2012,6,30), 366),
                  ((2011,1,1,2012,8,8), 585 ),
                  ((1900,1,1,1999,12,31), 36523)]
