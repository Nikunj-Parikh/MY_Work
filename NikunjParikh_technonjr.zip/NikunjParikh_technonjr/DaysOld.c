#include <stdio.h>
#include <stlib.h>
int year1, month1, day1, year2, month2, day2, year3,month3,day3;
void year(int day1,int month1,int year1,int day2,int month2,int year2);
void main()
{
printf("please enter the current date \n");
printf("enter the day");
scanf("%d",&day1);
printf("enter the month");
scanf("%d",&month1);
printf("enter the year");
scanf("%d",&year1);
printf("enter the day");
scanf("%d",&day2);
printf("enter the month");
scanf("%d",&month2);
printf("enter the year");
scanf("%d",&year2);
year(day1,month1,year1,day2,month2,year2);
}

void year(int day1,int month1,int year1,int day2,int month2,int year2)
{
    if(d2>d1)
    {
    month1=month1-1;
    day1=day1+30;
    }
    if(month2>month1)
    {
    year1=year1-1;
    month1=month1+12;
    }
    if(year2>year1)
    {
    exit(0);
    }
    day3=day1-day2;
    month3=month1-month2;
    year3=year1-year2;
    printf("current age is \n day %d \n month %d \n year %d ",day3,month3,year3);
}

//test case
# Test Cases

output(is_leap_baby(05, 6, 1990), �Aaditya�)
#>>>Aaditya is one of an extremely rare species. He is a leap year baby!

output(is_leap_baby(19, 6, 1978), �Robert�)
#>>>There's nothing special about Robert�s birthday. He is not a leap year baby!

output(is_leap_baby(29, 2, 2000), 'Hobbes')
#>>>Hobbes is one of an extremely rare species. He is a leap year baby!

output(is_leap_baby(29, 2, 1900), 'Charlie Brown')
#>>>There's nothing special about Charlie Brown's birthday. He is not a leap year baby!

output(is_leap_baby(28, 2, 1976), 'Odie')
#>>>There's nothing special about Odie's birthday. He is not a leap year baby!
